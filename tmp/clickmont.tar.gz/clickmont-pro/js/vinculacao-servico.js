/**
 * CLICKMONT PRO - SISTEMA DE VINCULAÇÃO DE SERVIÇOS
 * Gerencia vinculação de montadores, cancelamentos e penalidades
 */

class VinculacaoServico {
    constructor() {
        this.config = {
            MAX_CANCELAMENTOS: CONFIG.MAX_CANCELAMENTOS,
            DIAS_SUSPENSAO: CONFIG.DIAS_SUSPENSAO,
            BONUS_URGENCIA: CONFIG.BONUS_URGENCIA
        };
    }

    /**
     * Vincular montador ao job após aceitar
     */
    async vincularMontador(jobId, montadorId, montadorName, valorLance) {
        try {
            const vinculacao = {
                id: this.gerarVinculacaoId(),
                jobId,
                montadorId,
                montadorName,
                valorLance,
                vinculadoEm: new Date().toISOString(),
                status: 'active',
                cancelamentos: 0
            };

            const response = await fetch(CONFIG.API_VINCULACOES, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(vinculacao)
            });

            if (!response.ok) {
                throw new Error('Erro ao vincular montador');
            }

            // Atualizar status do job
            await this.atualizarStatusJob(jobId, 'accepted', montadorId, valorLance);

            // Notificar cliente
            await this.notificarCliente(jobId, montadorName);

            ConfigHelper.log(`Montador ${montadorName} vinculado ao job ${jobId}`, 'info');
            return vinculacao;

        } catch (error) {
            ConfigHelper.log(`Erro ao vincular montador: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Cancelar vinculação
     */
    async cancelarVinculacao(vinculacaoId, motivoCancelamento, canceladoPor) {
        try {
            // Buscar vinculação
            const vinculacao = await this.buscarVinculacao(vinculacaoId);

            if (!vinculacao) {
                throw new Error('Vinculação não encontrada');
            }

            // Atualizar vinculação
            const vinculacaoAtualizada = {
                ...vinculacao,
                status: 'cancelled',
                canceladoEm: new Date().toISOString(),
                motivoCancelamento,
                canceladoPor
            };

            await fetch(`${CONFIG.API_VINCULACOES}/${vinculacaoId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(vinculacaoAtualizada)
            });

            // Se cancelado pelo montador, incrementar contador
            if (canceladoPor === 'montador') {
                await this.registrarCancelamentoMontador(vinculacao.montadorId);
                await this.realocarServicoUrgente(vinculacao.jobId, vinculacao);
            } else {
                // Se cancelado pelo cliente, liberar montador sem penalidade
                await this.liberarMontador(vinculacao.montadorId);
            }

            ConfigHelper.log(`Vinculação ${vinculacaoId} cancelada`, 'warn');
            return true;

        } catch (error) {
            ConfigHelper.log(`Erro ao cancelar vinculação: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Registrar cancelamento do montador e aplicar penalidade se necessário
     */
    async registrarCancelamentoMontador(montadorId) {
        try {
            // Buscar montador
            const response = await fetch(`${CONFIG.API_MONTADORES}?id=${montadorId}`);
            const montadores = await response.json();
            const montador = montadores[0];

            if (!montador) {
                throw new Error('Montador não encontrado');
            }

            // Incrementar cancelamentos
            const novosCancelamentos = (montador.cancelamentos || 0) + 1;

            // Verificar se atingiu o limite
            if (novosCancelamentos >= this.config.MAX_CANCELAMENTOS) {
                await this.suspenderMontador(montadorId, novosCancelamentos);
            } else {
                // Apenas atualizar contador
                await fetch(`${CONFIG.API_MONTADORES}/${montadorId}`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        cancelamentos: novosCancelamentos,
                        ultimoCancelamento: new Date().toISOString()
                    })
                });

                // Enviar aviso
                await this.enviarAvisoCancelamento(montador, novosCancelamentos);
            }

            ConfigHelper.log(`Cancelamento registrado para montador ${montadorId}: ${novosCancelamentos}`, 'warn');

        } catch (error) {
            ConfigHelper.log(`Erro ao registrar cancelamento: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Suspender montador por excesso de cancelamentos
     */
    async suspenderMontador(montadorId, totalCancelamentos) {
        try {
            const dataFimSuspensao = new Date();
            dataFimSuspensao.setDate(dataFimSuspensao.getDate() + this.config.DIAS_SUSPENSAO);

            await fetch(`${CONFIG.API_MONTADORES}/${montadorId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    status: 'suspended',
                    cancelamentos: totalCancelamentos,
                    suspensaoInicio: new Date().toISOString(),
                    suspensaoFim: dataFimSuspensao.toISOString(),
                    motivoSuspensao: `Excesso de cancelamentos (${totalCancelamentos})`
                })
            });

            // Notificar montador
            await this.notificarSuspensao(montadorId, dataFimSuspensao);

            ConfigHelper.log(`Montador ${montadorId} suspenso por ${this.config.DIAS_SUSPENSAO} dias`, 'error');

        } catch (error) {
            ConfigHelper.log(`Erro ao suspender montador: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Realocar serviço como urgente
     */
    async realocarServicoUrgente(jobId, vinculacaoAnterior) {
        try {
            // Buscar job
            const response = await fetch(`${CONFIG.API_JOBS}?id=${jobId}`);
            const jobs = await response.json();
            const job = jobs[0];

            if (!job) {
                throw new Error('Job não encontrado');
            }

            // Calcular valor com bônus de urgência
            const valorOriginal = parseFloat(job.acceptedBidAmount);
            const valorUrgencia = valorOriginal * (1 + this.config.BONUS_URGENCIA);

            // Atualizar job como urgente
            const jobAtualizado = {
                status: 'urgent',
                urgentAmount: valorUrgencia,
                canceladoPor: vinculacaoAnterior.montadorName,
                urgentSince: new Date().toISOString()
            };

            await fetch(`${CONFIG.API_JOBS}/${jobId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(jobAtualizado)
            });

            // Notificar montadores sobre oportunidade urgente
            await this.notificarMontadoresUrgencia(job, valorUrgencia);

            ConfigHelper.log(`Job ${jobId} realocado como urgente com valor R$ ${valorUrgencia.toFixed(2)}`, 'info');

        } catch (error) {
            ConfigHelper.log(`Erro ao realocar serviço urgente: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Notificações
     */
    async notificarMontadoresUrgencia(job, valorUrgencia) {
        // Implementar notificação de serviço urgente
        // Envia para montadores próximos informando sobre +10% e isenção de taxa
        ConfigHelper.log(`Notificando montadores sobre serviço urgente: ${job.id}`, 'info');

        if (CONFIG.ENABLE_TEST_MODE) {
            console.log(`[TEST MODE] Serviço urgente disponível: +${CONFIG.BONUS_URGENCIA * 100}% e sem taxa`);
        }
    }

    async notificarCliente(jobId, montadorName) {
        ConfigHelper.log(`Cliente notificado: montador ${montadorName} aceitou o serviço`, 'info');
    }

    async enviarAvisoCancelamento(montador, totalCancelamentos) {
        const restantes = this.config.MAX_CANCELAMENTOS - totalCancelamentos;
        ConfigHelper.log(`Aviso enviado ao montador ${montador.name}: ${restantes} cancelamentos restantes`, 'warn');
    }

    async notificarSuspensao(montadorId, dataFimSuspensao) {
        ConfigHelper.log(`Notificação de suspensão enviada para montador ${montadorId} até ${dataFimSuspensao.toISOString()}`, 'error');
    }

    /**
     * Helpers
     */
    async buscarVinculacao(vinculacaoId) {
        const response = await fetch(`${CONFIG.API_VINCULACOES}?id=${vinculacaoId}`);
        const vinculacoes = await response.json();
        return vinculacoes[0];
    }

    async atualizarStatusJob(jobId, status, montadorId, valorLance) {
        await fetch(`${CONFIG.API_JOBS}/${jobId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status,
                acceptedMontadorId: montadorId,
                acceptedBidAmount: valorLance,
                acceptedAt: new Date().toISOString()
            })
        });
    }

    async liberarMontador(montadorId) {
        // Não incrementa cancelamentos quando cliente cancela
        ConfigHelper.log(`Montador ${montadorId} liberado sem penalidade`, 'info');
    }

    gerarVinculacaoId() {
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000);
        return `VIN${timestamp}${random}`;
    }

    /**
     * Verificar status de montador
     */
    async verificarDisponibilidadeMontador(montadorId) {
        try {
            const response = await fetch(`${CONFIG.API_MONTADORES}?id=${montadorId}`);
            const montadores = await response.json();
            const montador = montadores[0];

            if (!montador) {
                return { disponivel: false, motivo: 'Montador não encontrado' };
            }

            if (montador.status === 'suspended') {
                const fimSuspensao = new Date(montador.suspensaoFim);
                const hoje = new Date();

                if (hoje < fimSuspensao) {
                    return {
                        disponivel: false,
                        motivo: `Suspenso até ${fimSuspensao.toLocaleDateString('pt-BR')}`,
                        dias: Math.ceil((fimSuspensao - hoje) / (1000 * 60 * 60 * 24))
                    };
                } else {
                    // Suspensão expirou, reativar
                    await this.reativarMontador(montadorId);
                    return { disponivel: true };
                }
            }

            if (montador.status !== 'active') {
                return { disponivel: false, motivo: 'Conta inativa' };
            }

            return { disponivel: true };

        } catch (error) {
            ConfigHelper.log(`Erro ao verificar disponibilidade: ${error.message}`, 'error');
            return { disponivel: false, motivo: 'Erro ao verificar status' };
        }
    }

    async reativarMontador(montadorId) {
        await fetch(`${CONFIG.API_MONTADORES}/${montadorId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'active',
                cancelamentos: 0,
                reativadoEm: new Date().toISOString()
            })
        });

        ConfigHelper.log(`Montador ${montadorId} reativado`, 'info');
    }
}

// Instância global
const vinculacaoService = new VinculacaoServico();
