/**
 * CLICKMONT PRO - MONTADOR.JS
 * Funcionalidades da área do montador
 */

// Estado global do montador
let montadorLogado = null;

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    // Verificar se já está logado
    verificarLogin();

    // Configurar formulário de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Configurar tabs
    configurarTabs();

    // Configurar cálculo de lance
    const valorLanceInput = document.getElementById('valorLance');
    if (valorLanceInput) {
        valorLanceInput.addEventListener('input', calcularValoresLance);
    }

    // Carregar opções de chat
    carregarOpcoesChat();

    // Verificar se veio do aceite de termos
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('cadastro') === 'true') {
        mostrarFormularioCadastro();
    }
});

// Verificar login
function verificarLogin() {
    const montadorSalvo = localStorage.getItem('montadorLogado');
    if (montadorSalvo) {
        montadorLogado = JSON.parse(montadorSalvo);
        mostrarDashboard();
        carregarDadosMontador();
    }
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const senha = document.getElementById('loginSenha').value;

    // Mostrar loading
    const btnSubmit = e.target.querySelector('button[type="submit"]');
    const textoOriginal = btnSubmit.innerHTML;
    btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
    btnSubmit.disabled = true;

    try {
        // Aqui seria a chamada real à API
        // Por enquanto, simular login de teste
        if (email === 'montador@teste.com' && senha === '123456') {
            montadorLogado = {
                id: 'M001',
                nome: 'João Silva',
                email: email,
                telefone: '(19) 99999-9999',
                avaliacao: 4.8,
                jobsConcluidos: 12,
                cancelamentos: 0
            };

            localStorage.setItem('montadorLogado', JSON.stringify(montadorLogado));
            mostrarDashboard();
            carregarDadosMontador();
        } else {
            alert('Email ou senha incorretos!\n\nPara teste, use:\nEmail: montador@teste.com\nSenha: 123456');
        }
    } catch (error) {
        console.error('Erro no login:', error);
        alert('Erro ao fazer login. Tente novamente.');
    } finally {
        btnSubmit.innerHTML = textoOriginal;
        btnSubmit.disabled = false;
    }
}

// Mostrar dashboard
function mostrarDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
}

// Carregar dados do montador
async function carregarDadosMontador() {
    if (!montadorLogado) return;

    // Atualizar cabeçalho
    document.getElementById('montadorNome').textContent = montadorLogado.nome;
    document.getElementById('montadorAvaliacao').textContent = montadorLogado.avaliacao;
    document.getElementById('montadorJobs').textContent = montadorLogado.jobsConcluidos;

    // Carregar estatísticas
    await carregarEstatisticas();

    // Carregar jobs disponíveis
    await carregarJobsDisponiveis();
}

// Carregar estatísticas
async function carregarEstatisticas() {
    try {
        // Aqui seria chamada à API
        // Por enquanto, dados mockados
        document.getElementById('statDisponiveis').textContent = '5';
        document.getElementById('statEmAndamento').textContent = '2';
        document.getElementById('statLances').textContent = '3';
        document.getElementById('statGanhos').textContent = 'R$ 1.240';
    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}

// Carregar jobs disponíveis
async function carregarJobsDisponiveis() {
    try {
        // Aqui seria chamada à API do Sheet.best
        const url = ConfigHelper.getApiUrl('jobs');

        // Por enquanto, usar dados mockados
        console.log('Carregando jobs de:', url);

        // Jobs já estão no HTML como exemplo
    } catch (error) {
        console.error('Erro ao carregar jobs:', error);
    }
}

// Configurar tabs
function configurarTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;

            // Remover active de todos
            tabBtns.forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(t => {
                t.style.display = 'none';
                t.classList.remove('active');
            });

            // Adicionar active ao clicado
            btn.classList.add('active');
            const tabContent = document.getElementById('tab' + capitalize(tabName));
            if (tabContent) {
                tabContent.style.display = 'block';
                tabContent.classList.add('active');
            }
        });
    });
}

// Abrir modal de lance
function abrirModalLance(jobId) {
    const modal = document.getElementById('modalLance');
    modal.classList.add('active');
    modal.style.display = 'flex';

    // Carregar detalhes do job
    // Por enquanto, usar dados fixos
}

// Fechar modal
function fecharModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('active');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

// Calcular valores do lance
function calcularValoresLance() {
    const valorLance = parseFloat(document.getElementById('valorLance').value) || 0;

    // Verificar se é urgente (por enquanto, fixo como true)
    const isUrgente = true;

    const taxa = isUrgente ? 0 : (valorLance * CONFIG.TAXA_MONTADOR);
    const valorReceber = isUrgente ? valorLance : (valorLance - taxa);

    // Atualizar display
    document.getElementById('calcValorLance').textContent = 'R$ ' + valorLance.toFixed(2);
    document.getElementById('calcTaxa').textContent = 'R$ ' + taxa.toFixed(2);
    document.getElementById('calcReceber').textContent = 'R$ ' + valorReceber.toFixed(2);
}

// Enviar lance
async function enviarLance() {
    const valorLance = parseFloat(document.getElementById('valorLance').value);
    const observacoes = document.getElementById('observacoesLance').value;
    const confirmoInstalacao = document.getElementById('confirmoInstalacao').checked;

    // Validações
    if (!valorLance || valorLance < CONFIG.MIN_BID_VALUE) {
        alert('O valor mínimo do lance é R$ ' + CONFIG.MIN_BID_VALUE);
        return;
    }

    if (!confirmoInstalacao) {
        alert('Você deve confirmar que possui ferramentas e experiência para instalação em parede.');
        return;
    }

    // Confirmar
    if (!confirm(`Confirmar lance de R$ ${valorLance.toFixed(2)}?\n\nVocê receberá: R$ ${valorLance.toFixed(2)} (serviço urgente - isento de taxa)`)) {
        return;
    }

    try {
        // Aqui seria a chamada à API
        const bidData = {
            jobId: 'job1',
            montadorId: montadorLogado.id,
            montadorNome: montadorLogado.nome,
            valor: valorLance,
            observacoes: observacoes,
            data: new Date().toISOString(),
            status: 'ativo'
        };

        console.log('Enviando lance:', bidData);

        // Simular envio
        await new Promise(resolve => setTimeout(resolve, 1000));

        alert('Lance enviado com sucesso!\n\nVocê será notificado se for selecionado pelo cliente.');
        fecharModal('modalLance');

        // Limpar formulário
        document.getElementById('formLance').reset();
        document.getElementById('valorLance').value = '';
        calcularValoresLance();

    } catch (error) {
        console.error('Erro ao enviar lance:', error);
        alert('Erro ao enviar lance. Tente novamente.');
    }
}

// Carregar opções de chat
function carregarOpcoesChat() {
    const chatOptions = document.getElementById('chatOptions');
    if (!chatOptions) return;

    const mensagensMontador = CONFIG.CHAT_MESSAGES.montador;

    chatOptions.innerHTML = '';
    mensagensMontador.forEach(msg => {
        const btn = document.createElement('button');
        btn.className = 'chat-option-btn';
        btn.textContent = msg.text.replace('{nome_montador}', montadorLogado?.nome || 'Montador');
        btn.onclick = () => enviarMensagemChat(msg.text);
        chatOptions.appendChild(btn);
    });
}

// Enviar mensagem do chat
function enviarMensagemChat(texto) {
    const chatMessages = document.getElementById('chatMessages');

    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message sent';

    const textoFinal = texto
        .replace('{nome_montador}', montadorLogado?.nome || 'Montador')
        .replace('{data}', '20/02/2024')
        .replace('{horario}', '14:00');

    messageDiv.innerHTML = `
        <p>${textoFinal}</p>
        <div class="chat-message-time">${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
    `;

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Aqui seria enviado para a API
    console.log('Mensagem enviada:', textoFinal);
}

// Logout
function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        localStorage.removeItem('montadorLogado');
        montadorLogado = null;
        window.location.reload();
    }
}

// Mostrar formulário de cadastro
function mostrarFormularioCadastro() {
    alert('Cadastro em desenvolvimento!\n\nPor enquanto, use a conta de teste:\nEmail: montador@teste.com\nSenha: 123456');
}

// Utilidades
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Registrar Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(registration => {
            console.log('Service Worker registrado:', registration);
        })
        .catch(error => {
            console.error('Erro ao registrar Service Worker:', error);
        });
}
