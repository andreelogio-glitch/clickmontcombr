/**
 * CLICKMONT PRO - SCRIPT PRINCIPAL
 * Gerenciamento de solicitações de montagem
 */

// ========== NAVEGAÇÃO SUAVE ==========
function scrollToForm() {
    document.getElementById('formSection').scrollIntoView({
        behavior: 'smooth'
    });
}

// ========== GEOLOCALIZAÇÃO ==========
class GeolocalizacaoService {
    static async obterCoordenadas() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocalização não suportada'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                position => {
                    resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                },
                error => {
                    ConfigHelper.log(`Erro de geolocalização: ${error.message}`, 'warn');
                    reject(error);
                }
            );
        });
    }

    static async geocodificarEndereco(endereco) {
        try {
            // Usar API de geocodificação (ex: Nominatim OpenStreetMap - gratuita)
            const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(endereco)}&countrycodes=br`;
            const response = await fetch(url);
            const data = await response.json();

            if (data && data.length > 0) {
                return {
                    latitude: parseFloat(data[0].lat),
                    longitude: parseFloat(data[0].lon)
                };
            }
            return null;
        } catch (error) {
            ConfigHelper.log(`Erro ao geocodificar: ${error.message}`, 'error');
            return null;
        }
    }

    static calcularDistancia(lat1, lon1, lat2, lon2) {
        // Fórmula de Haversine
        const R = 6371; // Raio da Terra em km
        const dLat = this.toRad(lat2 - lat1);
        const dLon = this.toRad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    static toRad(valor) {
        return valor * Math.PI / 180;
    }
}

// ========== GERENCIAMENTO DE JOBS ==========
class JobManager {
    static async criarJob(dadosJob) {
        try {
            // Geocodificar endereço
            const coordenadas = await GeolocalizacaoService.geocodificarEndereco(dadosJob.address);

            const job = {
                id: this.gerarJobId(),
                clientName: dadosJob.clientName,
                clientEmail: dadosJob.clientEmail,
                clientPhone: dadosJob.clientPhone,
                clientAddress: dadosJob.clientAddress,
                latitude: coordenadas?.latitude || null,
                longitude: coordenadas?.longitude || null,
                serviceType: dadosJob.serviceType,
                furnitureDescription: dadosJob.furnitureDescription,
                furnitureQuantity: dadosJob.furnitureQuantity,
                hasWallInstallation: dadosJob.hasWallInstallation,
                preferredDate: dadosJob.preferredDate,
                additionalNotes: dadosJob.additionalNotes || '',
                status: 'open',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };

            // Salvar no Sheet.best
            const response = await fetch(CONFIG.API_JOBS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(job)
            });

            if (!response.ok) {
                throw new Error('Erro ao criar job');
            }

            ConfigHelper.log(`Job criado: ${job.id}`, 'info');

            // Notificar montadores próximos
            await this.notificarMontadores(job);

            return job;
        } catch (error) {
            ConfigHelper.log(`Erro ao criar job: ${error.message}`, 'error');
            throw error;
        }
    }

    static async notificarMontadores(job) {
        try {
            // Buscar montadores ativos
            const response = await fetch(CONFIG.API_MONTADORES);
            const montadores = await response.json();

            const montadoresProximos = montadores
                .filter(m => m.status === 'active' && m.cancelamentos < CONFIG.MAX_CANCELAMENTOS)
                .map(m => {
                    const distancia = GeolocalizacaoService.calcularDistancia(
                        job.latitude,
                        job.longitude,
                        m.latitude,
                        m.longitude
                    );
                    return { ...m, distancia };
                })
                .filter(m => m.distancia <= CONFIG.RAIO_BUSCA_KM)
                .sort((a, b) => a.distancia - b.distancia)
                .slice(0, CONFIG.MAX_MONTADORES_NOTIFICADOS);

            ConfigHelper.log(`Notificando ${montadoresProximos.length} montadores`, 'info');

            // Aqui você implementaria o envio de notificações
            // (email, push notification, SMS, etc)
            for (const montador of montadoresProximos) {
                await this.enviarNotificacao(montador, job);
            }

            return montadoresProximos;
        } catch (error) {
            ConfigHelper.log(`Erro ao notificar montadores: ${error.message}`, 'error');
        }
    }

    static async enviarNotificacao(montador, job) {
        // Implementar envio de notificação
        // Exemplo: Email, Push, SMS
        if (CONFIG.EMAIL_NOTIFICATIONS && !CONFIG.ENABLE_TEST_MODE) {
            // Aqui você integraria com serviço de email (ex: SendGrid, Mailgun)
            ConfigHelper.log(`Email enviado para ${montador.email}`, 'info');
        }

        if (CONFIG.ENABLE_TEST_MODE) {
            console.log(`[TEST MODE] Notificação para ${montador.name}: Job ${job.id}`);
        }
    }

    static gerarJobId() {
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000);
        return `JOB${timestamp}${random}`;
    }
}

// ========== VALIDAÇÃO DE FORMULÁRIO ==========
class FormValidator {
    static validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    static validarTelefone(telefone) {
        const regex = /^[\d\s\(\)\-\+]+$/;
        return regex.test(telefone) && telefone.replace(/\D/g, '').length >= 10;
    }

    static validarData(data) {
        const dataObj = new Date(data);
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        return dataObj >= hoje;
    }

    static validarFormulario(dados) {
        const erros = [];

        if (!dados.clientName || dados.clientName.trim().length < 3) {
            erros.push('Nome deve ter pelo menos 3 caracteres');
        }

        if (!this.validarEmail(dados.clientEmail)) {
            erros.push('Email inválido');
        }

        if (!this.validarTelefone(dados.clientPhone)) {
            erros.push('Telefone inválido');
        }

        if (!dados.clientAddress || dados.clientAddress.trim().length < 10) {
            erros.push('Endereço completo é obrigatório');
        }

        if (!dados.serviceType) {
            erros.push('Selecione o tipo de serviço');
        }

        if (!dados.furnitureDescription || dados.furnitureDescription.trim().length < 10) {
            erros.push('Descreva os móveis com mais detalhes');
        }

        if (!dados.furnitureQuantity || dados.furnitureQuantity < 1) {
            erros.push('Quantidade de móveis deve ser pelo menos 1');
        }

        if (!dados.preferredDate || !this.validarData(dados.preferredDate)) {
            erros.push('Selecione uma data válida (hoje ou futura)');
        }

        return erros;
    }
}

// ========== UI HELPERS ==========
class UIHelper {
    static mostrarLoading(mensagem = 'Carregando...') {
        const loading = document.createElement('div');
        loading.id = 'loadingOverlay';
        loading.className = 'loading-overlay';
        loading.innerHTML = `
            <div class="loading-spinner">
                <i class="fas fa-spinner fa-spin fa-3x"></i>
                <p>${mensagem}</p>
            </div>
        `;
        document.body.appendChild(loading);
    }

    static esconderLoading() {
        const loading = document.getElementById('loadingOverlay');
        if (loading) {
            loading.remove();
        }
    }

    static mostrarMensagem(mensagem, tipo = 'success') {
        const alerta = document.createElement('div');
        alerta.className = `alert alert-${tipo}`;
        alerta.innerHTML = `
            <i class="fas fa-${tipo === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i>
            <span>${mensagem}</span>
        `;

        document.body.appendChild(alerta);

        setTimeout(() => {
            alerta.classList.add('fade-out');
            setTimeout(() => alerta.remove(), 300);
        }, 5000);
    }

    static mostrarErros(erros) {
        const mensagem = erros.join('<br>');
        this.mostrarMensagem(mensagem, 'error');
    }
}

// ========== INICIALIZAÇÃO DO FORMULÁRIO ==========
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('jobForm');

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Coletar dados do formulário
            const dadosJob = {
                clientName: document.getElementById('clientName').value,
                clientEmail: document.getElementById('clientEmail').value,
                clientPhone: document.getElementById('clientPhone').value,
                clientAddress: document.getElementById('clientAddress').value,
                serviceType: document.getElementById('serviceType').value,
                furnitureDescription: document.getElementById('furnitureDescription').value,
                furnitureQuantity: parseInt(document.getElementById('furnitureQuantity').value),
                hasWallInstallation: document.getElementById('hasWallInstallation').checked,
                preferredDate: document.getElementById('preferredDate').value,
                additionalNotes: document.getElementById('additionalNotes').value
            };

            // Validar
            const erros = FormValidator.validarFormulario(dadosJob);
            if (erros.length > 0) {
                UIHelper.mostrarErros(erros);
                return;
            }

            // Enviar
            try {
                UIHelper.mostrarLoading('Enviando sua solicitação...');

                const job = await JobManager.criarJob(dadosJob);

                UIHelper.esconderLoading();
                UIHelper.mostrarMensagem(
                    'Solicitação enviada com sucesso! Em breve você receberá propostas de montadores.',
                    'success'
                );

                // Limpar formulário
                form.reset();

                // Rolar para o topo
                window.scrollTo({ top: 0, behavior: 'smooth' });

            } catch (error) {
                UIHelper.esconderLoading();
                UIHelper.mostrarMensagem(
                    'Erro ao enviar solicitação. Tente novamente ou entre em contato via WhatsApp.',
                    'error'
                );
                ConfigHelper.log(`Erro no envio: ${error.message}`, 'error');
            }
        });

        // Configurar data mínima (hoje)
        const campoData = document.getElementById('preferredDate');
        if (campoData) {
            const hoje = new Date().toISOString().split('T')[0];
            campoData.min = hoje;
        }
    }
});

// ========== SERVICE WORKER (PWA) ==========
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => ConfigHelper.log('Service Worker registrado', 'info'))
            .catch(err => ConfigHelper.log(`Erro no Service Worker: ${err}`, 'error'));
    });
}
