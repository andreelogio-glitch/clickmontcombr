/**
 * CLICKMONT PRO - SISTEMA DE PAGAMENTO AUTOMÁTICO
 *
 * Regras de Pagamento:
 * 1. Serviço simples (só montagem):
 *    - Cliente paga: valor do lance + 20%
 *    - Montador recebe: valor do lance - 10%
 *    - Plataforma: 30% total (20% + 10%)
 *    - Pagamento liberado após aprovação do cliente
 *
 * 2. Com desmontagem + montagem:
 *    - 40% liberado após desmontagem aprovada pelo cliente
 *    - 60% liberado após montagem aprovada pelo cliente
 *    - Taxas: Cliente +20%, Montador -10% (igual serviço simples)
 *
 * 3. Serviços urgentes (cancelados por outro montador):
 *    - Cliente paga: (valor + 10% bônus) + 20% taxa plataforma
 *    - Montador recebe: valor + 10% bônus (SEM desconto de 10%)
 *    - Plataforma: apenas 20% do cliente
 *
 * 4. Plataforma recebe 30% total (20% cliente + 10% montador)
 *    - Exceção: urgente = apenas 20% do cliente
 *
 * 5. IMPORTANTE: Instalação em parede obrigatória quando aplicável
 *    - Se não instalar, 40% do valor da montagem é retido
 *    - Valor usado para contratar outro profissional
 */

class PagamentoFracionado {
    constructor() {
        this.config = {
            TAXA_CLIENTE: CONFIG.TAXA_CLIENTE,
            TAXA_MONTADOR: CONFIG.TAXA_MONTADOR,
            PERCENTUAL_DESMONTAGEM: CONFIG.PERCENTUAL_DESMONTAGEM,
            PERCENTUAL_MONTAGEM: CONFIG.PERCENTUAL_MONTAGEM,
            BONUS_URGENCIA: CONFIG.BONUS_URGENCIA,
            PENALIDADE_NAO_INSTALACAO: CONFIG.PENALIDADE_NAO_INSTALACAO
        };
    }

    /**
     * Calcula valores do pagamento
     */
    calcularPagamento(valorLanceMontador, temDesmontagem, isUrgente = false) {
        // Calcular valor que o cliente vai pagar
        let valorBase = valorLanceMontador;

        if (isUrgente) {
            // Serviço urgente: adiciona 10% de bônus
            valorBase = valorLanceMontador * (1 + this.config.BONUS_URGENCIA);
        }

        const valorCliente = valorBase * (1 + this.config.TAXA_CLIENTE);

        // Calcular valor que o montador vai receber
        // Se urgente, montador não paga os 10%
        const taxaMontador = isUrgente ? 0 : this.config.TAXA_MONTADOR;
        const valorMontador = valorBase * (1 - taxaMontador);

        // Calcular valor da plataforma
        const taxaCliente = valorBase * this.config.TAXA_CLIENTE;
        const taxaMontadorValor = valorBase * taxaMontador;
        const valorPlataforma = taxaCliente + taxaMontadorValor;

        const resultado = {
            valorLanceMontador,
            valorCliente,
            valorMontador,
            valorPlataforma,
            taxaCliente,
            taxaMontadorValor,
            isUrgente,
            temDesmontagem
        };

        if (temDesmontagem) {
            resultado.parcelas = this.calcularParcelas(valorMontador);
        }

        return resultado;
    }

    /**
     * Calcula parcelas para desmontagem + montagem
     */
    calcularParcelas(valorTotal) {
        return {
            desmontagem: {
                percentual: this.config.PERCENTUAL_DESMONTAGEM,
                valor: valorTotal * this.config.PERCENTUAL_DESMONTAGEM,
                status: 'pending'
            },
            montagem: {
                percentual: this.config.PERCENTUAL_MONTAGEM,
                valor: valorTotal * this.config.PERCENTUAL_MONTAGEM,
                status: 'pending'
            }
        };
    }

    /**
     * Renderiza informações de pagamento para o cliente
     */
    renderizarInfoCliente(pagamento) {
        const html = `
            <div class="info-pagamento-cliente">
                <h3>
                    <i class="fas fa-shield-alt"></i>
                    Pagamento Seguro e Justo
                </h3>

                <div class="valor-total">
                    <span class="label">Valor Total:</span>
                    <span class="valor">R$ ${pagamento.valorCliente.toFixed(2)}</span>
                </div>

                ${pagamento.temDesmontagem ? this.renderizarParcelasCliente(pagamento) : ''}

                <div class="info-pagamento-detalhes">
                    <i class="fas fa-info-circle"></i>
                    <p>
                        ${pagamento.temDesmontagem
                            ? 'O pagamento será liberado automaticamente após você aprovar cada etapa do serviço.'
                            : 'O pagamento será liberado automaticamente após você aprovar o serviço.'}
                    </p>
                </div>

                <div class="garantias">
                    <h4>Suas Garantias:</h4>
                    <ul>
                        <li><i class="fas fa-check"></i> Você só paga após aprovar o serviço</li>
                        <li><i class="fas fa-check"></i> Profissionais verificados</li>
                        <li><i class="fas fa-check"></i> Suporte ClickMont em caso de problemas</li>
                        <li><i class="fas fa-check"></i> Instalação em parede incluída (quando aplicável)</li>
                    </ul>
                </div>
            </div>
        `;

        return html;
    }

    renderizarParcelasCliente(pagamento) {
        return `
            <div class="info-pagamento-etapas">
                <h4>Pagamento em 2 Etapas:</h4>

                <div class="etapa-pagamento">
                    <div class="etapa-header">
                        <i class="fas fa-tools"></i>
                        <span>1ª Etapa - Desmontagem</span>
                    </div>
                    <div class="etapa-valor">
                        40% = R$ ${pagamento.parcelas.desmontagem.valor.toFixed(2)}
                    </div>
                    <p class="etapa-info">Liberado após você aprovar a desmontagem</p>
                </div>

                <div class="etapa-pagamento">
                    <div class="etapa-header">
                        <i class="fas fa-hammer"></i>
                        <span>2ª Etapa - Montagem</span>
                    </div>
                    <div class="etapa-valor">
                        60% = R$ ${pagamento.parcelas.montagem.valor.toFixed(2)}
                    </div>
                    <p class="etapa-info">Liberado após você aprovar a montagem completa</p>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza informações de pagamento para o montador
     */
    renderizarInfoMontador(pagamento) {
        const html = `
            <div class="info-pagamento-montador">
                <h3>Informações de Pagamento</h3>

                ${pagamento.isUrgente ? `
                    <div class="alerta-urgente">
                        <i class="fas fa-bolt"></i>
                        <strong>Serviço Urgente!</strong>
                        <p>Você receberá +10% de bônus e está isento da taxa de 10%</p>
                    </div>
                ` : ''}

                <div class="valores-montador">
                    <div class="valor-item">
                        <span class="label">Valor do seu lance:</span>
                        <span class="valor">R$ ${pagamento.valorLanceMontador.toFixed(2)}</span>
                    </div>

                    ${pagamento.isUrgente ? `
                        <div class="valor-item bonus">
                            <span class="label">Bônus urgência (+10%):</span>
                            <span class="valor">+ R$ ${(pagamento.valorLanceMontador * this.config.BONUS_URGENCIA).toFixed(2)}</span>
                        </div>
                    ` : `
                        <div class="valor-item taxa">
                            <span class="label">Taxa plataforma (-10%):</span>
                            <span class="valor">- R$ ${pagamento.taxaMontadorValor.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="valor-item total">
                        <span class="label">Você receberá:</span>
                        <span class="valor destaque">R$ ${pagamento.valorMontador.toFixed(2)}</span>
                    </div>
                </div>

                ${pagamento.temDesmontagem ? this.renderizarParcelasMontador(pagamento) : ''}

                <div class="info-pagamento-detalhes">
                    <h4>Como Funciona:</h4>
                    <ul>
                        <li><i class="fas fa-info-circle"></i> Cliente paga via plataforma</li>
                        ${pagamento.temDesmontagem
                            ? '<li><i class="fas fa-info-circle"></i> 40% liberado após cliente aprovar desmontagem</li>' +
                              '<li><i class="fas fa-info-circle"></i> 60% liberado após cliente aprovar montagem</li>'
                            : '<li><i class="fas fa-info-circle"></i> Pagamento liberado após cliente aprovar o serviço</li>'}
                        <li><i class="fas fa-info-circle"></i> Valor cai em até 24h úteis na sua conta</li>
                    </ul>
                </div>

                <div class="alerta-instalacao-parede">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>IMPORTANTE:</strong>
                    <p>Se o serviço incluir instalação em parede e você não realizá-la, 40% do valor da montagem será retido para contratar outro profissional.</p>
                </div>
            </div>
        `;

        return html;
    }

    renderizarParcelasMontador(pagamento) {
        return `
            <div class="parcelas-montador">
                <h4>Recebimento em 2 Etapas:</h4>

                <div class="parcela-item">
                    <div class="parcela-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div class="parcela-info">
                        <span class="parcela-titulo">Após Desmontagem</span>
                        <span class="parcela-valor">R$ ${pagamento.parcelas.desmontagem.valor.toFixed(2)} (40%)</span>
                    </div>
                </div>

                <div class="parcela-item">
                    <div class="parcela-icon">
                        <i class="fas fa-hammer"></i>
                    </div>
                    <div class="parcela-info">
                        <span class="parcela-titulo">Após Montagem</span>
                        <span class="parcela-valor">R$ ${pagamento.parcelas.montagem.valor.toFixed(2)} (60%)</span>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Processar aprovação de etapa
     */
    async aprovarEtapa(jobId, etapa) {
        try {
            // etapa: 'desmontagem' ou 'montagem' ou 'completo'
            const pagamento = {
                jobId,
                etapa,
                aprovedAt: new Date().toISOString(),
                status: 'approved'
            };

            const response = await fetch(CONFIG.API_PAGAMENTOS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(pagamento)
            });

            if (!response.ok) {
                throw new Error('Erro ao processar aprovação');
            }

            // Processar pagamento via Mercado Pago
            await this.processarPagamentoMercadoPago(jobId, etapa);

            ConfigHelper.log(`Etapa ${etapa} aprovada para job ${jobId}`, 'info');
            return true;

        } catch (error) {
            ConfigHelper.log(`Erro ao aprovar etapa: ${error.message}`, 'error');
            throw error;
        }
    }

    async processarPagamentoMercadoPago(jobId, etapa) {
        // Integração com Mercado Pago
        // Implementar chamada à API do Mercado Pago
        ConfigHelper.log(`Processando pagamento MP para job ${jobId}, etapa ${etapa}`, 'info');

        if (CONFIG.ENABLE_TEST_MODE) {
            console.log(`[TEST MODE] Pagamento processado: Job ${jobId}, Etapa ${etapa}`);
            return { success: true, test: true };
        }

        // Aqui você implementaria a chamada real ao Mercado Pago
    }

    /**
     * Aplicar penalidade por não instalação em parede
     */
    async aplicarPenalidadeInstalacao(jobId, montadorId) {
        try {
            const job = await this.buscarJob(jobId);
            const valorPenalidade = job.acceptedBidAmount * this.config.PENALIDADE_NAO_INSTALACAO;

            const penalidade = {
                jobId,
                montadorId,
                tipo: 'nao_instalacao_parede',
                valorRetido: valorPenalidade,
                aplicadaEm: new Date().toISOString(),
                motivo: 'Não realizou instalação em parede conforme acordado'
            };

            await fetch(CONFIG.API_PAGAMENTOS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(penalidade)
            });

            ConfigHelper.log(`Penalidade aplicada: R$ ${valorPenalidade.toFixed(2)}`, 'warn');
            return valorPenalidade;

        } catch (error) {
            ConfigHelper.log(`Erro ao aplicar penalidade: ${error.message}`, 'error');
            throw error;
        }
    }

    async buscarJob(jobId) {
        const response = await fetch(`${CONFIG.API_JOBS}?id=${jobId}`);
        const jobs = await response.json();
        return jobs[0];
    }
}

// Instância global
const pagamentoService = new PagamentoFracionado();
