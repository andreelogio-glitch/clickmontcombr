/**
 * CLICKMONT PRO - CONFIGURAÇÃO GLOBAL
 *
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Substitua os IDs das planilhas do Sheet.best após criar suas planilhas Google Sheets
 * 2. Configure as credenciais do Mercado Pago
 * 3. Atualize as informações de contato
 */

const CONFIG = {
    // ========== SHEET.BEST API ENDPOINTS ==========
    // IMPORTANTE: Substitua 'YOUR_XXXX_SHEET_ID' pelos IDs reais das suas planilhas
    API_JOBS: 'https://sheet.best/api/sheets/YOUR_JOBS_SHEET_ID',
    API_MONTADORES: 'https://sheet.best/api/sheets/YOUR_MONTADORES_SHEET_ID',
    API_BIDS: 'https://sheet.best/api/sheets/YOUR_BIDS_SHEET_ID',
    API_CHAT: 'https://sheet.best/api/sheets/YOUR_CHAT_SHEET_ID',
    API_VINCULACOES: 'https://sheet.best/api/sheets/YOUR_VINCULACOES_SHEET_ID',
    API_PAGAMENTOS: 'https://sheet.best/api/sheets/YOUR_PAGAMENTOS_SHEET_ID',
    API_ACEITE_INSTALACAO: 'https://sheet.best/api/sheets/YOUR_ACEITE_INSTALACAO_SHEET_ID',

    // ========== MERCADO PAGO ==========
    MERCADOPAGO_PUBLIC_KEY: 'YOUR_MERCADOPAGO_PUBLIC_KEY',
    MERCADOPAGO_ACCESS_TOKEN: 'YOUR_MERCADOPAGO_ACCESS_TOKEN', // Apenas backend

    // ========== TAXAS E VALORES ==========
    TAXA_CLIENTE: 0.20,              // Cliente paga 20% a mais
    TAXA_MONTADOR: 0.10,             // Montador recebe 10% a menos
    TAXA_TOTAL_PLATAFORMA: 0.30,    // Total da plataforma: 30%
    BONUS_URGENCIA: 0.10,            // Bônus de 10% para serviços urgentes
    ISENTO_TAXA_URGENTE: true,       // Montador de serviço urgente não paga os 10%

    // ========== PENALIDADES E LIMITES ==========
    MAX_CANCELAMENTOS: 3,            // Máximo de cancelamentos permitidos
    DIAS_SUSPENSAO: 30,              // Dias de suspensão após exceder cancelamentos
    PENALIDADE_NAO_INSTALACAO: 0.40, // 40% retido se não instalar em parede

    // ========== PAGAMENTO FRACIONADO ==========
    PERCENTUAL_DESMONTAGEM: 0.40,    // 40% após desmontagem aprovada
    PERCENTUAL_MONTAGEM: 0.60,       // 60% após montagem aprovada

    // ========== GEOLOCALIZAÇÃO ==========
    RAIO_BUSCA_KM: 50,               // Raio de busca de montadores (km)
    MAX_MONTADORES_NOTIFICADOS: 10,  // Máximo de montadores notificados por job

    // ========== CONTATO ==========
    TELEFONE_COMERCIAL: '19998760212',
    WHATSAPP_COMERCIAL: '5519998760212',
    EMAIL_CONTATO: 'contato@clickmont.com.br',
    EMAIL_SUPORTE: 'suporte@clickmont.com.br',

    // ========== CHAT BLINDADO ==========
    CHAT_MESSAGES: {
        montador: [
            { id: 'm1', text: 'Olá! Sou {nome_montador}, vou realizar sua montagem.' },
            { id: 'm2', text: 'Que dia o(a) Sr(a) deseja combinar?' },
            { id: 'm3', text: 'Podemos agendar para {data}?' },
            { id: 'm4', text: 'Confirmo presença para {data} às {horario}.' },
            { id: 'm5', text: 'Estou a caminho!' },
            { id: 'm6', text: 'Cheguei no local.' },
            { id: 'm7', text: 'Desmontagem concluída. Por favor, verifique e aprove.' },
            { id: 'm8', text: 'Montagem concluída. Por favor, verifique o serviço.' },
            { id: 'm9', text: 'Obrigado pela confiança!' }
        ],
        cliente: [
            { id: 'c1', text: 'Olá! Aguardo confirmação.' },
            { id: 'c2', text: 'Prefiro {data}.' },
            { id: 'c3', text: 'Confirmo para {data} às {horario}.' },
            { id: 'c4', text: 'Ok, aguardo sua chegada.' },
            { id: 'c5', text: 'Pode subir/entrar.' },
            { id: 'c6', text: 'Desmontagem aprovada!' },
            { id: 'c7', text: 'Serviço aprovado! Obrigado.' },
            { id: 'c8', text: 'Preciso fazer uma observação sobre o serviço.' },
            { id: 'c9', text: 'Obrigado pelo ótimo trabalho!' }
        ]
    },

    // ========== NOTIFICAÇÕES ==========
    EMAIL_NOTIFICATIONS: true,
    PUSH_NOTIFICATIONS: true,
    SMS_NOTIFICATIONS: false,

    // ========== PWA ==========
    APP_NAME: 'ClickMont Pro',
    APP_SHORT_NAME: 'ClickMont',
    APP_VERSION: '1.0.0',

    // ========== VALIDAÇÕES ==========
    MIN_BID_VALUE: 50,               // Valor mínimo de lance (R$)
    MAX_BID_VALUE: 10000,            // Valor máximo de lance (R$)
    MAX_DESCRIPTION_LENGTH: 1000,    // Máximo de caracteres na descrição

    // ========== DESENVOLVIMENTO ==========
    DEBUG_MODE: false,               // Ativar logs de debug
    ENABLE_TEST_MODE: false          // Modo de teste (não envia notificações reais)
};

// ========== VALIDAÇÃO DE CONFIGURAÇÃO ==========
function validarConfiguracao() {
    const erros = [];

    // Verificar se os IDs das planilhas foram configurados
    if (CONFIG.API_JOBS.includes('YOUR_')) {
        erros.push('Configure o API_JOBS com o ID real da planilha');
    }
    if (CONFIG.API_MONTADORES.includes('YOUR_')) {
        erros.push('Configure o API_MONTADORES com o ID real da planilha');
    }
    if (CONFIG.MERCADOPAGO_PUBLIC_KEY.includes('YOUR_')) {
        erros.push('Configure as credenciais do Mercado Pago');
    }

    if (erros.length > 0 && !CONFIG.ENABLE_TEST_MODE) {
        console.warn('⚠️ CONFIGURAÇÕES PENDENTES:', erros);
    }

    return erros.length === 0;
}

// ========== FUNÇÕES AUXILIARES ==========
const ConfigHelper = {
    // Verificar se está em modo de produção
    isProduction() {
        return !CONFIG.DEBUG_MODE && !CONFIG.ENABLE_TEST_MODE;
    },

    // Obter URL da API com validação
    getApiUrl(endpoint) {
        const urls = {
            'jobs': CONFIG.API_JOBS,
            'montadores': CONFIG.API_MONTADORES,
            'bids': CONFIG.API_BIDS,
            'chat': CONFIG.API_CHAT,
            'vinculacoes': CONFIG.API_VINCULACOES,
            'pagamentos': CONFIG.API_PAGAMENTOS,
            'aceite_instalacao': CONFIG.API_ACEITE_INSTALACAO
        };

        return urls[endpoint] || null;
    },

    // Formatar telefone para WhatsApp
    formatWhatsAppUrl(mensagem = '') {
        return `https://wa.me/${CONFIG.WHATSAPP_COMERCIAL}${mensagem ? '?text=' + encodeURIComponent(mensagem) : ''}`;
    },

    // Calcular valor com taxa
    calcularValorCliente(valorBase) {
        return valorBase * (1 + CONFIG.TAXA_CLIENTE);
    },

    // Calcular valor para montador
    calcularValorMontador(valorBase, isUrgente = false) {
        const taxa = isUrgente && CONFIG.ISENTO_TAXA_URGENTE ? 0 : CONFIG.TAXA_MONTADOR;
        return valorBase * (1 - taxa);
    },

    // Calcular valor da plataforma
    calcularValorPlataforma(valorBase, isUrgente = false) {
        const taxaCliente = valorBase * CONFIG.TAXA_CLIENTE;
        const taxaMontador = isUrgente && CONFIG.ISENTO_TAXA_URGENTE ? 0 : (valorBase * CONFIG.TAXA_MONTADOR);
        return taxaCliente + taxaMontador;
    },

    // Validar se montador pode receber jobs
    verificarStatusMontador(cancelamentos) {
        return cancelamentos < CONFIG.MAX_CANCELAMENTOS;
    },

    // Log com controle de ambiente
    log(mensagem, tipo = 'info') {
        if (CONFIG.DEBUG_MODE) {
            const timestamp = new Date().toISOString();
            console[tipo](`[${timestamp}] ${mensagem}`);
        }
    }
};

// Validar configuração ao carregar
document.addEventListener('DOMContentLoaded', () => {
    if (CONFIG.DEBUG_MODE) {
        console.log('🔧 ClickMont Pro - Modo Debug Ativado');
        console.log('📋 Configuração:', CONFIG);
    }
    validarConfiguracao();
});

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CONFIG, ConfigHelper };
}
