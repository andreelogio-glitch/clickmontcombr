/**
 * CLICKMONT PRO - ALERTA DE INSTALAÇÃO EM PAREDE
 * Sistema de alerta obrigatório quando montador dá lance em serviço
 */

class AlertaInstalacao {
    /**
     * Mostrar alerta quando montador der lance
     */
    static mostrarAlerta(valorLance, hasWallInstallation, callback) {
        // Se não tem instalação em parede, não precisa do alerta
        if (!hasWallInstallation) {
            if (callback) callback(true);
            return;
        }

        const modal = this.criarModal(valorLance);
        document.body.appendChild(modal);

        // Configurar eventos
        const btnConfirmar = modal.querySelector('#btnConfirmarInstalacao');
        const btnCancelar = modal.querySelector('#btnCancelarInstalacao');
        const checkbox = modal.querySelector('#checkAceiteInstalacao');

        checkbox.addEventListener('change', () => {
            btnConfirmar.disabled = !checkbox.checked;
        });

        btnConfirmar.addEventListener('click', async () => {
            modal.remove();
            if (callback) callback(true);
        });

        btnCancelar.addEventListener('click', () => {
            modal.remove();
            if (callback) callback(false);
        });
    }

    static criarModal(valorLance) {
        const valorPenalidade = valorLance * CONFIG.PENALIDADE_NAO_INSTALACAO;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay modal-alerta-instalacao';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header alerta-header">
                    <div class="alerta-icon-wrapper">
                        <i class="fas fa-exclamation-triangle alerta-icon-pulse"></i>
                    </div>
                    <h2>⚠️ ATENÇÃO: Instalação em Parede</h2>
                </div>

                <div class="modal-body">
                    <div class="alerta-box importante">
                        <h3>
                            <i class="fas fa-hammer"></i>
                            Este serviço INCLUI instalação em parede
                        </h3>
                        <p>O cliente informou que há móveis para instalação em parede (prateleiras, armários suspensos, etc).</p>
                    </div>

                    <div class="regras-instalacao">
                        <h4>Regras Importantes:</h4>
                        <ul>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <strong>Seu lance DEVE incluir a instalação em parede</strong>
                            </li>
                            <li>
                                <i class="fas fa-times-circle"></i>
                                <strong>Você NÃO pode alegar desconhecimento posterior</strong>
                            </li>
                            <li>
                                <i class="fas fa-tools"></i>
                                <strong>Inclua ferramentas e materiais necessários</strong> (buchas, parafusos, furadeira, nível, etc)
                            </li>
                        </ul>
                    </div>

                    <div class="alerta-box penalidade">
                        <h4>
                            <i class="fas fa-exclamation-triangle"></i>
                            Penalidade por Não Instalação
                        </h4>
                        <div class="penalidade-info">
                            <p>Se você aceitar o serviço e <strong>não realizar a instalação em parede:</strong></p>
                            <div class="penalidade-valor">
                                <i class="fas fa-hand-holding-usd"></i>
                                <span>
                                    <strong>40% do valor da montagem</strong> será retido
                                    <br>
                                    <small>(R$ ${valorPenalidade.toFixed(2)} do seu lance de R$ ${valorLance.toFixed(2)})</small>
                                </span>
                            </div>
                            <p class="penalidade-uso">
                                <i class="fas fa-info-circle"></i>
                                Este valor será usado pela plataforma para contratar outro profissional que realize a instalação.
                            </p>
                        </div>
                    </div>

                    <div class="alerta-box contestacao">
                        <h4>
                            <i class="fas fa-headset"></i>
                            Em Caso de Problemas
                        </h4>
                        <p>
                            Se houver algum impedimento técnico real para a instalação (parede inadequada, ausência de ferramentas específicas acordadas com cliente, etc),
                            você pode abrir um ticket de contestação com a equipe ClickMont <strong>ANTES</strong> de finalizar o serviço.
                        </p>
                    </div>

                    <div class="aceite-instalacao">
                        <label class="checkbox-container">
                            <input type="checkbox" id="checkAceiteInstalacao">
                            <span class="checkmark"></span>
                            <span class="checkbox-label">
                                <strong>Li e compreendi todas as informações acima.</strong>
                                Tenho ciência de que devo incluir a instalação em parede no meu orçamento e que,
                                caso não a realize, estarei sujeito à retenção de 40% do valor da montagem.
                            </span>
                        </label>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="btnCancelarInstalacao">
                        <i class="fas fa-times"></i>
                        Cancelar Lance
                    </button>
                    <button type="button" class="btn btn-primary" id="btnConfirmarInstalacao" disabled>
                        <i class="fas fa-check"></i>
                        Confirmar e Dar Lance
                    </button>
                </div>

                <div class="modal-footer-info">
                    <i class="fas fa-shield-alt"></i>
                    <small>Este alerta é obrigatório para proteger clientes e profissionais</small>
                </div>
            </div>
        `;

        return modal;
    }

    /**
     * Salvar aceite do montador
     */
    static async salvarAceiteInstalacao(montadorId, jobId, valorLance) {
        try {
            const aceite = {
                montadorId,
                jobId,
                valorLance,
                termoInstalacao: true,
                dataAceite: new Date().toISOString(),
                ipAddress: await this.obterIP()
            };

            const response = await fetch(CONFIG.API_ACEITE_INSTALACAO, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(aceite)
            });

            if (!response.ok) {
                throw new Error('Erro ao salvar aceite');
            }

            ConfigHelper.log(`Aceite de instalação salvo: ${jobId}`, 'info');
            return true;

        } catch (error) {
            ConfigHelper.log(`Erro ao salvar aceite: ${error.message}`, 'error');
            return false;
        }
    }

    static async obterIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch {
            return 'unknown';
        }
    }

    /**
     * Verificar se montador já aceitou termos para este job
     */
    static async verificarAceite(montadorId, jobId) {
        try {
            const response = await fetch(`${CONFIG.API_ACEITE_INSTALACAO}?montadorId=${montadorId}&jobId=${jobId}`);
            const aceites = await response.json();
            return aceites.length > 0;
        } catch (error) {
            ConfigHelper.log(`Erro ao verificar aceite: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Mostrar resumo de instalação para cliente
     */
    static renderizarInfoCliente(hasWallInstallation) {
        if (!hasWallInstallation) return '';

        return `
            <div class="info-instalacao-cliente">
                <div class="info-header">
                    <i class="fas fa-hammer"></i>
                    <h4>Instalação em Parede Incluída</h4>
                </div>
                <div class="info-body">
                    <p>
                        <i class="fas fa-check-circle"></i>
                        Seu serviço inclui instalação em parede.
                        Todos os montadores que derem lances estão cientes disso e
                        <strong>devem incluir este serviço no orçamento</strong>.
                    </p>
                    <p>
                        <i class="fas fa-shield-alt"></i>
                        <strong>Garantia ClickMont:</strong> Se o montador não realizar a instalação,
                        a plataforma reterá 40% do valor para contratar outro profissional.
                    </p>
                </div>
            </div>
        `;
    }

    /**
     * Badge de instalação em parede para cards de job
     */
    static renderizarBadge(hasWallInstallation) {
        if (!hasWallInstallation) return '';

        return `
            <span class="badge badge-instalacao" title="Instalação em parede incluída">
                <i class="fas fa-hammer"></i>
                Instalação em Parede
            </span>
        `;
    }
}

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AlertaInstalacao;
}
