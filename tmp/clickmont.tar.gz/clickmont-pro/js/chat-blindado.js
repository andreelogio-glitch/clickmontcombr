/**
 * CLICKMONT PRO - CHAT BLINDADO
 * Sistema de comunicação com frases pré-formuladas para proteger leads
 */

class ChatBlindado {
    constructor(jobId, userId, userType) {
        this.jobId = jobId;
        this.userId = userId;
        this.userType = userType; // 'montador' ou 'cliente'
        this.mensagens = [];
        this.init();
    }

    init() {
        this.carregarMensagens();
        this.renderizarInterface();
        this.iniciarAtualizacaoAutomatica();
    }

    async carregarMensagens() {
        try {
            const response = await fetch(`${CONFIG.API_CHAT}?jobId=${this.jobId}`);
            this.mensagens = await response.json();
            this.atualizarInterface();
        } catch (error) {
            ConfigHelper.log(`Erro ao carregar mensagens: ${error.message}`, 'error');
        }
    }

    renderizarInterface() {
        const container = document.getElementById('chatContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="chat-blindado">
                <div class="chat-header">
                    <h3>
                        <i class="fas fa-shield-alt"></i>
                        Chat Seguro
                    </h3>
                    <p class="chat-info">Use apenas as frases pré-formuladas abaixo</p>
                </div>

                <div class="chat-messages" id="chatMessages">
                    ${this.renderizarMensagens()}
                </div>

                <div class="chat-frases-predefinidas">
                    <h4>Selecione uma frase:</h4>
                    <div class="frases-lista">
                        ${this.renderizarFrasesPredefinidas()}
                    </div>
                </div>

                <div class="chat-aviso">
                    <i class="fas fa-info-circle"></i>
                    <p>Para proteger sua privacidade e segurança, só é permitido usar frases pré-formuladas.</p>
                </div>
            </div>
        `;
    }

    renderizarMensagens() {
        if (this.mensagens.length === 0) {
            return `
                <div class="chat-vazio">
                    <i class="fas fa-comments"></i>
                    <p>Nenhuma mensagem ainda. Inicie a conversa!</p>
                </div>
            `;
        }

        return this.mensagens.map(msg => `
            <div class="chat-mensagem ${msg.senderId === this.userId ? 'enviada' : 'recebida'}">
                <div class="mensagem-header">
                    <span class="mensagem-autor">${msg.senderName}</span>
                    <span class="mensagem-data">${this.formatarData(msg.sentAt)}</span>
                </div>
                <div class="mensagem-texto">${msg.message}</div>
            </div>
        `).join('');
    }

    renderizarFrasesPredefinidas() {
        const frases = CONFIG.CHAT_MESSAGES[this.userType];

        return frases.map(frase => `
            <button class="frase-btn" onclick="chatBlindado.selecionarFrase('${frase.id}', '${frase.text.replace(/'/g, "\\'")}')">
                <i class="fas fa-comment-dots"></i>
                ${frase.text}
            </button>
        `).join('');
    }

    async selecionarFrase(fraseId, textoFrase) {
        // Verificar se precisa substituir variáveis
        const modal = this.criarModalVariaveis(textoFrase);

        if (modal) {
            document.body.appendChild(modal);
        } else {
            // Enviar diretamente se não tiver variáveis
            await this.enviarMensagem(textoFrase);
        }
    }

    criarModalVariaveis(textoFrase) {
        // Detectar variáveis no formato {variavel}
        const variaveis = textoFrase.match(/\{([^}]+)\}/g);

        if (!variaveis) return null;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>Complete as informações</h3>
                <form id="formVariaveis">
                    ${variaveis.map(v => {
                        const nomeVar = v.replace(/[{}]/g, '');
                        return `
                            <div class="form-group">
                                <label>${this.formatarNomeVariavel(nomeVar)}</label>
                                ${this.criarCampoVariavel(nomeVar)}
                            </div>
                        `;
                    }).join('')}
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">
                            Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            Enviar Mensagem
                        </button>
                    </div>
                </form>
            </div>
        `;

        modal.querySelector('form').addEventListener('submit', async (e) => {
            e.preventDefault();
            let textoFinal = textoFrase;

            // Substituir variáveis
            variaveis.forEach(v => {
                const nomeVar = v.replace(/[{}]/g, '');
                const valor = document.getElementById(`var_${nomeVar}`).value;
                textoFinal = textoFinal.replace(v, valor);
            });

            modal.remove();
            await this.enviarMensagem(textoFinal);
        });

        return modal;
    }

    criarCampoVariavel(nomeVar) {
        switch (nomeVar) {
            case 'data':
                return `<input type="date" id="var_${nomeVar}" required min="${new Date().toISOString().split('T')[0]}">`;
            case 'horario':
                return `<input type="time" id="var_${nomeVar}" required>`;
            case 'nome_montador':
                return `<input type="text" id="var_${nomeVar}" required>`;
            default:
                return `<input type="text" id="var_${nomeVar}" required>`;
        }
    }

    formatarNomeVariavel(nomeVar) {
        const nomes = {
            'data': 'Data',
            'horario': 'Horário',
            'nome_montador': 'Seu Nome'
        };
        return nomes[nomeVar] || nomeVar;
    }

    async enviarMensagem(texto) {
        try {
            const mensagem = {
                jobId: this.jobId,
                senderId: this.userId,
                senderName: await this.obterNomeUsuario(),
                senderType: this.userType,
                message: texto,
                sentAt: new Date().toISOString()
            };

            const response = await fetch(CONFIG.API_CHAT, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(mensagem)
            });

            if (!response.ok) {
                throw new Error('Erro ao enviar mensagem');
            }

            // Enviar notificação por email
            await this.notificarDestinatario(mensagem);

            // Recarregar mensagens
            await this.carregarMensagens();

            // Mostrar sucesso
            UIHelper.mostrarMensagem('Mensagem enviada!', 'success');

        } catch (error) {
            ConfigHelper.log(`Erro ao enviar mensagem: ${error.message}`, 'error');
            UIHelper.mostrarMensagem('Erro ao enviar mensagem', 'error');
        }
    }

    async obterNomeUsuario() {
        // Implementar busca do nome do usuário
        // Por enquanto, placeholder
        return this.userType === 'montador' ? 'Montador' : 'Cliente';
    }

    async notificarDestinatario(mensagem) {
        if (!CONFIG.EMAIL_NOTIFICATIONS || CONFIG.ENABLE_TEST_MODE) return;

        // Implementar envio de email ao destinatário
        ConfigHelper.log(`Notificação enviada sobre nova mensagem`, 'info');
    }

    atualizarInterface() {
        const messagesContainer = document.getElementById('chatMessages');
        if (messagesContainer) {
            messagesContainer.innerHTML = this.renderizarMensagens();
            // Scroll para última mensagem
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    iniciarAtualizacaoAutomatica() {
        // Atualizar a cada 10 segundos
        setInterval(() => {
            this.carregarMensagens();
        }, 10000);
    }

    formatarData(dataISO) {
        const data = new Date(dataISO);
        const hoje = new Date();

        const ehHoje = data.toDateString() === hoje.toDateString();

        const tempo = data.toLocaleTimeString('pt-BR', {
            hour: '2-digit',
            minute: '2-digit'
        });

        if (ehHoje) {
            return tempo;
        }

        const dia = data.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit'
        });

        return `${dia} ${tempo}`;
    }
}

// Variável global para acesso
let chatBlindado = null;

// Função para inicializar o chat
function inicializarChat(jobId, userId, userType) {
    chatBlindado = new ChatBlindado(jobId, userId, userType);
}
