/**
 * CLICKMONT PRO - ADMIN.JS
 * Funcionalidades do painel administrativo
 */

// Estado global do admin
let adminLogado = null;

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    // Verificar se já está logado
    verificarLoginAdmin();

    // Configurar formulário de login
    const adminLoginForm = document.getElementById('adminLoginForm');
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', handleAdminLogin);
    }

    // Configurar tabs
    configurarTabsAdmin();
});

// Verificar login admin
function verificarLoginAdmin() {
    const adminSalvo = localStorage.getItem('adminLogado');
    if (adminSalvo) {
        adminLogado = JSON.parse(adminSalvo);
        mostrarDashboardAdmin();
        carregarDadosAdmin();
    }
}

// Handle login admin
async function handleAdminLogin(e) {
    e.preventDefault();

    const email = document.getElementById('adminEmail').value;
    const senha = document.getElementById('adminSenha').value;

    // Mostrar loading
    const btnSubmit = e.target.querySelector('button[type="submit"]');
    const textoOriginal = btnSubmit.innerHTML;
    btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';
    btnSubmit.disabled = true;

    try {
        // Aqui seria a chamada real à API com autenticação segura
        // Por enquanto, simular login de teste
        if (email === 'admin@clickmont.com.br' && senha === 'admin123') {
            adminLogado = {
                id: 'ADM001',
                nome: 'Administrador',
                email: email,
                nivel: 'super_admin'
            };

            localStorage.setItem('adminLogado', JSON.stringify(adminLogado));
            mostrarDashboardAdmin();
            carregarDadosAdmin();
        } else {
            alert('Email ou senha incorretos!\n\nPara teste, use:\nEmail: admin@clickmont.com.br\nSenha: admin123');
        }
    } catch (error) {
        console.error('Erro no login admin:', error);
        alert('Erro ao fazer login. Tente novamente.');
    } finally {
        btnSubmit.innerHTML = textoOriginal;
        btnSubmit.disabled = false;
    }
}

// Mostrar dashboard admin
function mostrarDashboardAdmin() {
    document.getElementById('adminLoginSection').style.display = 'none';
    document.getElementById('adminDashboardSection').style.display = 'block';
}

// Carregar dados do admin
async function carregarDadosAdmin() {
    if (!adminLogado) return;

    // Atualizar cabeçalho
    document.getElementById('adminNome').textContent = adminLogado.nome;

    // Carregar estatísticas gerais
    await carregarEstatisticasGerais();
}

// Carregar estatísticas gerais
async function carregarEstatisticasGerais() {
    try {
        // Aqui seria chamada às APIs do Sheet.best
        // Por enquanto, dados mockados

        // Jobs ativos
        const jobsAtivos = await contarJobsAtivos();
        document.querySelector('#adminDashboardSection .grid-4 .card:nth-child(1) h3').textContent = jobsAtivos;

        // Montadores ativos
        const montadoresAtivos = await contarMontadoresAtivos();
        document.querySelector('#adminDashboardSection .grid-4 .card:nth-child(2) h3').textContent = montadoresAtivos;

        // Clientes
        const clientes = await contarClientes();
        document.querySelector('#adminDashboardSection .grid-4 .card:nth-child(3) h3').textContent = clientes;

        // Receita do mês
        const receita = await calcularReceitaMes();
        document.querySelector('#adminDashboardSection .grid-4 .card:nth-child(4) h3').textContent = 'R$ ' + receita.toFixed(2);

    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}

// Contar jobs ativos
async function contarJobsAtivos() {
    try {
        // Aqui seria a chamada à API
        const url = ConfigHelper.getApiUrl('jobs');
        console.log('Buscando jobs de:', url);

        // Mockado
        return 5;
    } catch (error) {
        console.error('Erro ao contar jobs:', error);
        return 0;
    }
}

// Contar montadores ativos
async function contarMontadoresAtivos() {
    try {
        const url = ConfigHelper.getApiUrl('montadores');
        console.log('Buscando montadores de:', url);

        // Mockado
        return 12;
    } catch (error) {
        console.error('Erro ao contar montadores:', error);
        return 0;
    }
}

// Contar clientes
async function contarClientes() {
    try {
        // Aqui seria a lógica para contar clientes únicos
        // Mockado
        return 8;
    } catch (error) {
        console.error('Erro ao contar clientes:', error);
        return 0;
    }
}

// Calcular receita do mês
async function calcularReceitaMes() {
    try {
        const url = ConfigHelper.getApiUrl('pagamentos');
        console.log('Buscando pagamentos de:', url);

        // Mockado
        return 1240.50;
    } catch (error) {
        console.error('Erro ao calcular receita:', error);
        return 0;
    }
}

// Configurar tabs admin
function configurarTabsAdmin() {
    const tabBtns = document.querySelectorAll('.admin-tab-btn');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;

            // Remover active de todos
            tabBtns.forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.admin-tab-content').forEach(t => {
                t.style.display = 'none';
                t.classList.remove('active');
            });

            // Adicionar active ao clicado
            btn.classList.add('active');
            const tabContent = document.getElementById('adminTab' + capitalize(tabName));
            if (tabContent) {
                tabContent.style.display = 'block';
                tabContent.classList.add('active');

                // Carregar dados da tab específica
                carregarDadosTab(tabName);
            }
        });
    });
}

// Carregar dados de uma tab específica
async function carregarDadosTab(tabName) {
    switch (tabName) {
        case 'jobs':
            await carregarJobsAdmin();
            break;
        case 'montadores':
            await carregarMontadoresAdmin();
            break;
        case 'clientes':
            await carregarClientesAdmin();
            break;
        case 'pagamentos':
            await carregarPagamentosAdmin();
            break;
        case 'config':
            carregarConfigAdmin();
            break;
    }
}

// Carregar jobs (admin)
async function carregarJobsAdmin() {
    try {
        const url = ConfigHelper.getApiUrl('jobs');
        console.log('Carregando jobs admin de:', url);

        // Aqui seria a chamada real à API
        // Por enquanto, os dados já estão no HTML como exemplo
    } catch (error) {
        console.error('Erro ao carregar jobs:', error);
    }
}

// Carregar montadores (admin)
async function carregarMontadoresAdmin() {
    try {
        const url = ConfigHelper.getApiUrl('montadores');
        console.log('Carregando montadores de:', url);

        // Dados já estão no HTML como exemplo
    } catch (error) {
        console.error('Erro ao carregar montadores:', error);
    }
}

// Carregar clientes (admin)
async function carregarClientesAdmin() {
    try {
        console.log('Carregando clientes...');

        // Dados já estão no HTML como exemplo
    } catch (error) {
        console.error('Erro ao carregar clientes:', error);
    }
}

// Carregar pagamentos (admin)
async function carregarPagamentosAdmin() {
    try {
        const url = ConfigHelper.getApiUrl('pagamentos');
        console.log('Carregando pagamentos de:', url);

        // Atualizar estatísticas de pagamento
        // Mockado
        document.querySelector('#adminTabPagamentos .grid-3 .card:nth-child(1) p').textContent = 'R$ 5.240,00';
        document.querySelector('#adminTabPagamentos .grid-3 .card:nth-child(2) p').textContent = 'R$ 1.572,00';
        document.querySelector('#adminTabPagamentos .grid-3 .card:nth-child(3) p').textContent = 'R$ 320,00';

        // Dados da tabela já estão no HTML
    } catch (error) {
        console.error('Erro ao carregar pagamentos:', error);
    }
}

// Carregar configurações (admin)
function carregarConfigAdmin() {
    console.log('Tab de configurações carregada');
    console.log('CONFIG atual:', CONFIG);
}

// Logout admin
function adminLogout() {
    if (confirm('Tem certeza que deseja sair do painel administrativo?')) {
        localStorage.removeItem('adminLogado');
        adminLogado = null;
        window.location.reload();
    }
}

// Utilidades
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Funções de ação (para botões da interface)
function visualizarJob(jobId) {
    alert('Visualizar job: ' + jobId + '\n\nFuncionalidade em desenvolvimento.');
}

function editarJob(jobId) {
    alert('Editar job: ' + jobId + '\n\nFuncionalidade em desenvolvimento.');
}

function visualizarMontador(montadorId) {
    alert('Visualizar montador: ' + montadorId + '\n\nFuncionalidade em desenvolvimento.');
}

function suspenderMontador(montadorId) {
    if (confirm('Tem certeza que deseja suspender este montador?')) {
        alert('Montador suspenso!\n\nFuncionalidade em desenvolvimento.');
    }
}

// Exportar relatórios
function exportarRelatorio(tipo) {
    alert('Exportar relatório: ' + tipo + '\n\nFuncionalidade em desenvolvimento.');
}

// Registrar Service Worker (se não foi registrado ainda)
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(registration => {
            console.log('Service Worker registrado (admin):', registration);
        })
        .catch(error => {
            console.error('Erro ao registrar Service Worker:', error);
        });
}
