# ClickMont Pro

## 📋 Descrição

ClickMont Pro é uma plataforma profissional de intermediação para montagem de móveis novos. Conectamos clientes a montadores qualificados com mais de 15 anos de experiência no mercado.

## ✨ Características Principais

- 🛠️ **Montagem Profissional**: Rede de montadores certificados
- 💳 **Pagamento Seguro**: Sistema integrado com Mercado Pago
- 💬 **Chat Blindado**: Comunicação protegida com frases pré-formuladas
- 📱 **PWA**: Instalável como aplicativo nativo
- 🔒 **Privacidade**: Proteção de dados pessoais (LGPD)
- ⚡ **Serviços Urgentes**: Bônus de 10% para realocações
- 🎯 **Geolocalização**: Montadores próximos ao cliente
- ⭐ **Sistema de Avaliações**: Reputação transparente

## 🏗️ Estrutura de Arquivos

```
clickmont-pro/
├── index.html                  # Página inicial (clientes)
├── montador.html              # Área do montador
├── admin.html                 # Painel administrativo
├── quem-somos.html            # Página institucional
├── termo-uso-montador.html    # Termos de uso
├── manifest.json              # PWA manifest
├── sw.js                      # Service Worker
├── css/
│   └── styles.css             # Estilos principais
├── js/
│   ├── config.js              # Configurações globais
│   ├── script.js              # Script principal (clientes)
│   ├── chat-blindado.js       # Sistema de chat
│   ├── pagamento-fracionado.js # Sistema de pagamentos
│   ├── alerta-instalacao.js   # Alertas de instalação
│   ├── vinculacao-servico.js  # Vinculação e penalidades
│   ├── montador.js            # Script área montador
│   └── admin.js               # Script painel admin
├── images/
│   └── logo-clickmont.png     # Logo (substitua com seu logo)
└── docs/
    └── GUIA-DEPLOY-VPS.md     # Guia de instalação VPS
```

## 💰 Sistema de Pagamento

### Taxas da Plataforma

- **Cliente paga**: Valor do lance + 20%
- **Montador recebe**: Valor do lance - 10%
- **Plataforma**: 30% total (20% + 10%)

### Serviços Urgentes

- **Montador recebe**: Valor + 10% bônus (isento da taxa de 10%)
- **Plataforma**: Apenas 20% do cliente

### Pagamento Fracionado

Para serviços com **desmontagem + montagem**:

- **40%** após aprovação da desmontagem
- **60%** após aprovação da montagem

## ⚠️ Instalação em Parede

**IMPORTANTE**: Quando aplicável, a instalação em parede é obrigatória.

- Montador é alertado ao dar o lance
- Deve incluir no orçamento
- **Penalidade**: 40% retido se não instalar
- Valor usado para contratar outro profissional

## 🚫 Sistema de Penalidades

### Cancelamentos

- **Máximo**: 3 cancelamentos
- **Penalidade**: Suspensão de 30 dias
- **Exceção**: Cancelamento pelo cliente não penaliza

### Suspensão

- Automática após 3 cancelamentos
- Duração: 30 dias
- Reativação automática após período

## 📱 Chat Blindado

Sistema de comunicação controlada para proteger leads:

- Apenas frases pré-formuladas
- Sem troca de telefones
- Notificações por email
- Variáveis dinâmicas (data, horário)

## 🔧 Configuração

### 1. Google Sheets + Sheet.best

Crie 7 planilhas no Google Sheets:

1. **jobs**: Solicitações de montagem
2. **montadores**: Cadastro de montadores
3. **bids**: Lances dos montadores
4. **chat**: Mensagens
5. **vinculacoes**: Vinculações job-montador
6. **pagamentos**: Transações
7. **aceite_instalacao**: Aceites de instalação

Configure cada planilha no [Sheet.best](https://sheet.best) e obtenha os IDs das APIs.

### 2. Mercado Pago

1. Crie conta no [Mercado Pago](https://www.mercadopago.com.br)
2. Acesse **Seu negócio → Credenciais**
3. Copie **Public Key** e **Access Token**

### 3. Atualizar CONFIG.js

Edite `js/config.js` e substitua:

```javascript
API_JOBS: 'https://sheet.best/api/sheets/SEU_ID_AQUI',
API_MONTADORES: 'https://sheet.best/api/sheets/SEU_ID_AQUI',
// ... demais APIs

MERCADOPAGO_PUBLIC_KEY: 'SUA_PUBLIC_KEY_AQUI',
MERCADOPAGO_ACCESS_TOKEN: 'SEU_ACCESS_TOKEN_AQUI',
```

### 4. Logo

Substitua `images/logo-clickmont.png` com seu logo (recomendado: 200x60px, PNG transparente).

## 📦 Dependências

### CDN (já incluídas no HTML)

- **Font Awesome 6.0.0**: Ícones
- **Google Fonts**: Roboto

### APIs Externas

- **Sheet.best**: Backend (Google Sheets)
- **Mercado Pago**: Pagamentos
- **Nominatim OpenStreetMap**: Geocodificação (gratuita)
- **ipify**: Obter IP do usuário

## 🚀 Deploy

Veja o guia completo em: `docs/GUIA-DEPLOY-VPS.md`

### Resumo Rápido

1. Upload via FTP/SFTP para VPS
2. Configurar domínio
3. Ativar SSL/HTTPS (obrigatório)
4. Testar todas funcionalidades

## 🌐 URLs Importantes

- **Homepage**: `/index.html`
- **Área Montador**: `/montador.html`
- **Admin**: `/admin.html`
- **Quem Somos**: `/quem-somos.html`
- **Termos**: `/termo-uso-montador.html`

## 📞 Contato

- **Telefone/WhatsApp**: (19) 99876-0212
- **Email**: contato@clickmont.com.br

## 🔒 Segurança

- ✅ HTTPS obrigatório
- ✅ Validação de formulários
- ✅ Proteção contra XSS
- ✅ LGPD compliance
- ✅ Dados sensíveis apenas via HTTPS

## 🧪 Modo de Teste

Para testar sem enviar notificações reais:

```javascript
// Em config.js
ENABLE_TEST_MODE: true,
DEBUG_MODE: true
```

## 📊 Estatísticas

O sistema rastreia automaticamente:

- Total de jobs criados
- Montadores ativos
- Lances realizados
- Taxa de conclusão
- Avaliações médias
- Cancelamentos

## 🆘 Suporte

Para dúvidas sobre configuração ou uso:

1. Leia o guia completo: `docs/GUIA-DEPLOY-VPS.md`
2. Verifique o console do navegador (F12)
3. Entre em contato via WhatsApp: (19) 99876-0212

## 📝 Licença

© 2024 ClickMont Pro. Todos os direitos reservados.

## 🔄 Versão

**v1.0.0** - Janeiro 2024

---

**Desenvolvido com ❤️ para conectar profissionais qualificados aos clientes**
