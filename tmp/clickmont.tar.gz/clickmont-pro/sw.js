/**
 * SERVICE WORKER - CLICKMONT PRO
 * PWA offline support e cache de recursos
 */

const CACHE_NAME = 'clickmont-pro-v1.0.0';
const CACHE_URLS = [
    '/',
    '/index.html',
    '/quem-somos.html',
    '/montador.html',
    '/admin.html',
    '/termo-uso-montador.html',
    '/css/styles.css',
    '/js/config.js',
    '/js/script.js',
    '/js/montador.js',
    '/js/admin.js',
    '/manifest.json',
    '/images/logo-clickmont.png'
];

// Instalação do Service Worker
self.addEventListener('install', (event) => {
    console.log('[Service Worker] Instalando...');

    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('[Service Worker] Cache aberto');
                return cache.addAll(CACHE_URLS.map(url => new Request(url, { cache: 'reload' })));
            })
            .catch((error) => {
                console.error('[Service Worker] Erro ao adicionar ao cache:', error);
            })
    );

    self.skipWaiting();
});

// Ativação do Service Worker
self.addEventListener('activate', (event) => {
    console.log('[Service Worker] Ativando...');

    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('[Service Worker] Removendo cache antigo:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );

    self.clients.claim();
});

// Interceptação de requisições
self.addEventListener('fetch', (event) => {
    // Ignora requisições que não são GET
    if (event.request.method !== 'GET') {
        return;
    }

    // Ignora requisições para APIs externas (Sheet.best, etc)
    if (event.request.url.includes('sheet.best') ||
        event.request.url.includes('mercadopago') ||
        event.request.url.includes('googleapis')) {
        return;
    }

    event.respondWith(
        caches.match(event.request)
            .then((response) => {
                // Retorna do cache se disponível
                if (response) {
                    console.log('[Service Worker] Retornando do cache:', event.request.url);
                    return response;
                }

                // Senão, busca da rede
                return fetch(event.request)
                    .then((response) => {
                        // Verifica se é uma resposta válida
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }

                        // Clona a resposta
                        const responseToCache = response.clone();

                        caches.open(CACHE_NAME)
                            .then((cache) => {
                                cache.put(event.request, responseToCache);
                            });

                        return response;
                    })
                    .catch((error) => {
                        console.error('[Service Worker] Erro ao buscar:', error);

                        // Retorna página offline se disponível
                        if (event.request.destination === 'document') {
                            return caches.match('/index.html');
                        }
                    });
            })
    );
});

// Mensagens do service worker
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }

    if (event.data && event.data.type === 'CLEAR_CACHE') {
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    return caches.delete(cacheName);
                })
            );
        }).then(() => {
            event.ports[0].postMessage({ success: true });
        });
    }

    if (event.data && event.data.type === 'CACHE_STATUS') {
        caches.open(CACHE_NAME).then((cache) => {
            return cache.keys();
        }).then((keys) => {
            event.ports[0].postMessage({
                cacheName: CACHE_NAME,
                cachedUrls: keys.length
            });
        });
    }
});

// Push Notifications (para futuro uso)
self.addEventListener('push', (event) => {
    console.log('[Service Worker] Push recebido:', event);

    const options = {
        body: event.data ? event.data.text() : 'Nova notificação do ClickMont Pro',
        icon: '/images/icon-192x192.png',
        badge: '/images/icon-96x96.png',
        vibrate: [200, 100, 200],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'explore',
                title: 'Ver detalhes',
                icon: '/images/icon-96x96.png'
            },
            {
                action: 'close',
                title: 'Fechar',
                icon: '/images/icon-96x96.png'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification('ClickMont Pro', options)
    );
});

// Clique em notificação
self.addEventListener('notificationclick', (event) => {
    console.log('[Service Worker] Notificação clicada:', event);

    event.notification.close();

    if (event.action === 'explore') {
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

// Sincronização em background (para futuro uso)
self.addEventListener('sync', (event) => {
    console.log('[Service Worker] Sincronização em background:', event);

    if (event.tag === 'sync-jobs') {
        event.waitUntil(syncJobs());
    }
});

async function syncJobs() {
    try {
        // Implementar sincronização de jobs quando offline
        console.log('[Service Worker] Sincronizando jobs...');
        return Promise.resolve();
    } catch (error) {
        console.error('[Service Worker] Erro ao sincronizar:', error);
        return Promise.reject(error);
    }
}

// Periodic Background Sync (para futuro uso)
self.addEventListener('periodicsync', (event) => {
    if (event.tag === 'update-jobs') {
        event.waitUntil(updateJobs());
    }
});

async function updateJobs() {
    try {
        console.log('[Service Worker] Atualizando jobs em background...');
        // Implementar atualização periódica
        return Promise.resolve();
    } catch (error) {
        console.error('[Service Worker] Erro ao atualizar:', error);
        return Promise.reject(error);
    }
}

console.log('[Service Worker] Carregado com sucesso!');
