# Guia Completo de Instalação - VPS Hostinger

## 📋 Índice

1. [Pré-requisitos](#pré-requisitos)
2. [Configuração do Google Sheets + Sheet.best](#configuração-do-google-sheets--sheetbest)
3. [Configuração do Mercado Pago](#configuração-do-mercado-pago)
4. [Upload para VPS Hostinger](#upload-para-vps-hostinger)
5. [Configuração de Domínio e SSL](#configuração-de-domínio-e-ssl)
6. [Atualização dos Arquivos](#atualização-dos-arquivos)
7. [Testes Finais](#testes-finais)
8. [Troubleshooting](#troubleshooting)

---

## 🎯 Pré-requisitos

Antes de começar, tenha em mãos:

- ✅ Conta na Hostinger com VPS ativo
- ✅ Domínio configurado (ex: clickmont.com.br)
- ✅ Conta Google (para Google Sheets)
- ✅ Conta Mercado Pago (para pagamentos)
- ✅ Cliente FTP (FileZilla, WinSCP, ou similar)

---

## 📊 Configuração do Google Sheets + Sheet.best

### Passo 1: Criar Planilhas no Google Sheets

1. Acesse [Google Sheets](https://sheets.google.com)
2. Crie uma nova planilha vazia
3. Crie 7 abas com os seguintes nomes EXATOS:

#### Aba 1: `jobs`

**Colunas** (primeira linha):
```
id | clientName | clientEmail | clientPhone | clientAddress | latitude | longitude | serviceType | furnitureDescription | furnitureQuantity | hasWallInstallation | preferredDate | additionalNotes | status | acceptedMontadorId | acceptedBidAmount | createdAt | updatedAt
```

#### Aba 2: `montadores`

**Colunas**:
```
id | name | email | phone | address | latitude | longitude | cpf | rg | bankAccount | bankAgency | bankName | pixKey | status | rating | totalJobs | cancelamentos | suspensaoInicio | suspensaoFim | createdAt
```

#### Aba 3: `bids`

**Colunas**:
```
id | jobId | montadorId | montadorName | bidAmount | observations | createdAt | status
```

#### Aba 4: `chat`

**Colunas**:
```
id | jobId | senderId | senderName | senderType | message | sentAt
```

#### Aba 5: `vinculacoes`

**Colunas**:
```
id | jobId | montadorId | montadorName | valorLance | vinculadoEm | status | canceladoEm | motivoCancelamento | canceladoPor
```

#### Aba 6: `pagamentos`

**Colunas**:
```
id | jobId | montadorId | valorTotal | etapa | aprovedAt | status | mercadopagoId | valorPlataforma | valorMontador
```

#### Aba 7: `aceite_instalacao`

**Colunas**:
```
id | montadorId | jobId | valorLance | termoInstalacao | dataAceite | ipAddress
```

### Passo 2: Configurar Sheet.best

**Para CADA aba**, faça:

1. Acesse [Sheet.best](https://sheet.best)
2. Clique em **"Create New Connection"**
3. Selecione **"Google Sheets"**
4. Clique em **"Sign in with Google"** e autorize
5. Selecione sua planilha
6. Selecione a aba específica (ex: `jobs`)
7. Clique em **"Create Connection"**
8. **COPIE o URL da API** gerado (ex: `https://sheet.best/api/sheets/abc123xyz`)
9. Guarde em um bloco de notas com o nome da aba

**Exemplo do seu bloco de notas:**
```
jobs: https://sheet.best/api/sheets/ABC123XYZ
montadores: https://sheet.best/api/sheets/DEF456UVW
bids: https://sheet.best/api/sheets/GHI789RST
chat: https://sheet.best/api/sheets/JKL012MNO
vinculacoes: https://sheet.best/api/sheets/PQR345STU
pagamentos: https://sheet.best/api/sheets/VWX678YZA
aceite_instalacao: https://sheet.best/api/sheets/BCD901EFG
```

---

## 💳 Configuração do Mercado Pago

### Passo 1: Criar Conta

1. Acesse [Mercado Pago](https://www.mercadopago.com.br)
2. Crie uma conta **Pessoa Jurídica** (se não tiver)
3. Complete o cadastro e verificação

### Passo 2: Obter Credenciais

1. Faça login no Mercado Pago
2. Vá em **Seu negócio** → **Configurações** → **Credenciais**
3. Você verá duas seções:
   - **Credenciais de teste** (para testar)
   - **Credenciais de produção** (para usar de verdade)

4. **Para começar**, use as **credenciais de teste**:
   - Copie a **Public Key** (começa com `TEST-...`)
   - Copie o **Access Token** (começa com `TEST-...`)

5. **Quando estiver pronto para produção**, troque para as credenciais de produção:
   - Copie a **Public Key** (começa com `APP_USR-...`)
   - Copie o **Access Token** (começa com `APP_USR-...`)

**Guarde as credenciais:**
```
Public Key: TEST-abc123-xyz789
Access Token: TEST-987654-qwerty
```

### Passo 3: Configurar Webhooks (Opcional mas Recomendado)

1. Em **Credenciais**, role até **Webhooks**
2. Clique em **Configurar notificações**
3. URL de notificação: `https://seudominio.com.br/webhook-mercadopago.php` (criar depois)
4. Selecione eventos: **payment**, **chargebacks**

---

## 📤 Upload para VPS Hostinger

### Método 1: Via Painel Hostinger (Mais Fácil)

#### Passo 1: Compactar Arquivos

1. No seu computador, selecione TODA a pasta `clickmont-pro`
2. Clique com botão direito → **Compactar** (ou **Zip**)
3. Renomeie para `clickmont-pro.zip`

#### Passo 2: Upload via File Manager

1. Acesse [Hostinger hPanel](https://hpanel.hostinger.com)
2. Selecione seu VPS
3. Vá em **Websites** → Selecione seu domínio
4. Clique em **File Manager**
5. Navegue até `/public_html` (ou `/htdocs`, depende da configuração)
6. Clique em **Upload** no canto superior direito
7. Selecione `clickmont-pro.zip` e aguarde o upload
8. Após upload, clique com botão direito no arquivo → **Extract**
9. Aguarde a extração
10. Entre na pasta `clickmont-pro` e **mova** todo o conteúdo para `/public_html`
    - Selecione todos os arquivos dentro de `clickmont-pro`
    - Clique em **Move**
    - Destino: `/public_html`
11. Delete a pasta vazia `clickmont-pro` e o arquivo `.zip`

### Método 2: Via FTP (Para Usuários Avançados)

#### Passo 1: Obter Credenciais FTP

1. No hPanel Hostinger, vá em **Websites** → **FTP Accounts**
2. Anote:
   - **Host**: ftp.seudominio.com.br
   - **Username**: seu_usuario@seudominio.com.br
   - **Port**: 21 (ou 22 para SFTP)
   - **Password**: sua_senha

#### Passo 2: Conectar via FileZilla

1. Abra o FileZilla
2. Arquivo → **Gestor de Sites**
3. Clique em **Novo Site**
4. Configure:
   - **Protocolo**: FTP (ou SFTP)
   - **Servidor**: ftp.seudominio.com.br
   - **Porta**: 21 (ou 22)
   - **Usuário**: seu_usuario@seudominio.com.br
   - **Senha**: sua_senha
5. Clique em **Conectar**

#### Passo 3: Upload dos Arquivos

1. No painel **Local** (esquerda), navegue até a pasta `clickmont-pro`
2. No painel **Remoto** (direita), navegue até `/public_html`
3. Selecione TODOS os arquivos da pasta `clickmont-pro` no lado esquerdo
4. Arraste para o lado direito (ou botão direito → **Upload**)
5. Aguarde a transferência (pode demorar alguns minutos)

---

## 🌐 Configuração de Domínio e SSL

### Passo 1: Verificar Domínio

1. No hPanel, vá em **Websites** → seu domínio
2. Verifique se está **ativo** e apontando para o VPS
3. Se não estiver, vá em **DNS/Nameservers** e configure

### Passo 2: Ativar SSL (HTTPS) - OBRIGATÓRIO

**MUITO IMPORTANTE**: PWA, geolocalização e Mercado Pago só funcionam com HTTPS!

1. No hPanel, vá em **Websites** → seu domínio
2. Procure por **SSL** no menu lateral
3. Clique em **Instalar SSL**
4. Selecione **Let's Encrypt** (gratuito)
5. Clique em **Instalar**
6. Aguarde 5-10 minutos para ativação

### Passo 3: Forçar HTTPS

1. Ainda em **SSL**, ative a opção **"Force HTTPS"**
2. Ou crie um arquivo `.htaccess` na raiz com:

```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## ✏️ Atualização dos Arquivos

### Passo 1: Editar config.js

1. No File Manager ou via FTP, abra `js/config.js`
2. Substitua os valores:

```javascript
const CONFIG = {
    // ===== COLE AQUI AS URLs DO SHEET.BEST =====
    API_JOBS: 'https://sheet.best/api/sheets/ABC123XYZ',
    API_MONTADORES: 'https://sheet.best/api/sheets/DEF456UVW',
    API_BIDS: 'https://sheet.best/api/sheets/GHI789RST',
    API_CHAT: 'https://sheet.best/api/sheets/JKL012MNO',
    API_VINCULACOES: 'https://sheet.best/api/sheets/PQR345STU',
    API_PAGAMENTOS: 'https://sheet.best/api/sheets/VWX678YZA',
    API_ACEITE_INSTALACAO: 'https://sheet.best/api/sheets/BCD901EFG',

    // ===== COLE AQUI AS CREDENCIAIS DO MERCADO PAGO =====
    MERCADOPAGO_PUBLIC_KEY: 'TEST-abc123-xyz789',
    MERCADOPAGO_ACCESS_TOKEN: 'TEST-987654-qwerty',

    // Resto já está configurado, mas você pode ajustar se quiser
    TAXA_CLIENTE: 0.20,
    TAXA_MONTADOR: 0.10,
    // ...
};
```

3. **Salve o arquivo**

### Passo 2: Substituir Logo

1. Prepare seu logo (formato PNG, tamanho recomendado: 200x60px, fundo transparente)
2. Renomeie para `logo-clickmont.png`
3. No File Manager ou FTP, navegue até `/images/`
4. Faça upload do seu logo (sobrescreva o existente)

### Passo 3: Verificar URLs

Acesse seu site:
- Homepage: `https://seudominio.com.br/index.html`
- Quem Somos: `https://seudominio.com.br/quem-somos.html`
- Montador: `https://seudominio.com.br/montador.html`

**Se aparecer erro 404**, verifique se os arquivos estão na raiz do `/public_html`.

---

## ✅ Testes Finais

### Teste 1: Homepage

1. Acesse `https://seudominio.com.br/index.html`
2. Verifique:
   - ✅ Logo aparece corretamente
   - ✅ Galeria de fotos carrega
   - ✅ Badge "15 anos" aparece
   - ✅ Formulário de solicitação está visível

### Teste 2: Criar Solicitação de Montagem

1. Preencha o formulário na homepage
2. Clique em **Enviar Solicitação**
3. Aguarde a mensagem de sucesso
4. **Verifique na planilha Google Sheets** (aba `jobs`) se o registro apareceu

**Se NÃO aparecer:**
- Abra o Console do navegador (F12 → Console)
- Veja se há erros vermelhos
- Verifique se as URLs do Sheet.best estão corretas no `config.js`

### Teste 3: Área do Montador

1. Acesse `https://seudominio.com.br/montador.html`
2. Para testar, primeiro crie um montador manualmente na planilha `montadores`:
   ```
   id: MONT001
   name: João Silva
   email: joao@teste.com
   phone: 19999999999
   password: 123456 (depois implementar hash)
   status: active
   rating: 4.8
   totalJobs: 0
   cancelamentos: 0
   ```
3. Faça login com email: `joao@teste.com` e senha: `123456`
4. Verifique se a área do montador carrega os jobs

### Teste 4: Chat Blindado

1. Após vincular um montador a um job, acesse o chat
2. Tente enviar uma mensagem pré-formulada
3. **Verifique na planilha `chat`** se a mensagem foi salva

### Teste 5: PWA (Instalação do App)

1. Acesse o site pelo **celular** (Android ou iPhone)
2. No **Chrome Android**: Menu → **Instalar App**
3. No **Safari iOS**: Compartilhar → **Adicionar à Tela Inicial**
4. Verifique se o app abre sem a barra de navegação

### Teste 6: Geolocalização

1. Ao criar uma solicitação, o navegador deve pedir permissão para acessar localização
2. Conceda permissão
3. Verifique se `latitude` e `longitude` foram preenchidas na planilha `jobs`

### Teste 7: SSL/HTTPS

1. Acesse o site
2. Verifique se há um **cadeado verde** ao lado da URL
3. Clique no cadeado → **Certificado válido**

**Se não tiver cadeado:**
- Aguarde mais alguns minutos (SSL pode demorar até 30 min)
- Verifique se forçou HTTPS no passo anterior
- Limpe cache do navegador (Ctrl+Shift+Del)

---

## 🐛 Troubleshooting

### Erro: "API_JOBS is not defined"

**Causa**: `config.js` não foi carregado corretamente.

**Solução**:
1. Verifique se `config.js` está em `/js/config.js`
2. No HTML, verifique se tem: `<script src="js/config.js"></script>` **ANTES** de `script.js`

### Erro: "Failed to fetch" no Console

**Causa**: URLs do Sheet.best incorretas ou CORS bloqueado.

**Solução**:
1. Verifique se as URLs do Sheet.best estão corretas (copie e cole novamente)
2. Teste a URL diretamente no navegador (deve retornar `[]` ou dados)
3. Verifique se o site está rodando em HTTPS (Sheet.best pode bloquear HTTP)

### Jobs não aparecem na planilha

**Causa**: API do Sheet.best não está recebendo dados.

**Solução**:
1. Abra o Console (F12) e veja se há erros
2. Verifique se a planilha tem exatamente as colunas especificadas
3. Teste manualmente com **Postman** ou **curl**:
   ```bash
   curl -X POST https://sheet.best/api/sheets/SEU_ID \
     -H "Content-Type: application/json" \
     -d '{"id":"TEST001","clientName":"Teste"}'
   ```

### PWA não instala no celular

**Causa**: Certificado SSL não está ativo ou `manifest.json` com erro.

**Solução**:
1. Verifique HTTPS (obrigatório para PWA)
2. Valide `manifest.json` em: https://manifest-validator.appspot.com/
3. Verifique se `manifest.json` está linkado no HTML:
   ```html
   <link rel="manifest" href="manifest.json">
   ```

### Chat não envia mensagens

**Causa**: API do `chat` não configurada ou JavaScript com erro.

**Solução**:
1. Verifique Console (F12) para erros
2. Confirme que `API_CHAT` está correto em `config.js`
3. Teste a API do chat diretamente

### Mercado Pago não abre

**Causa**: Public Key incorreta ou site em HTTP.

**Solução**:
1. Verifique se `MERCADOPAGO_PUBLIC_KEY` está correto
2. Use credenciais de **teste** primeiro (`TEST-...`)
3. Certifique-se que o site está em **HTTPS**

### Imagens não carregam

**Causa**: Caminho incorreto ou permissões de pasta.

**Solução**:
1. Verifique se a pasta `/images/` existe
2. No File Manager, clique com botão direito na pasta → **Permissions** → **755**
3. Verifique o caminho no HTML: `<img src="images/logo-clickmont.png">`

---

## 📧 Configurações Opcionais

### Email de Notificações

Para enviar emails quando houver novos jobs, lances, etc:

1. Use um serviço como **SendGrid**, **Mailgun** ou **SMTP da Hostinger**
2. Crie um arquivo `send-email.php` na raiz:

```php
<?php
// Configurar SMTP da Hostinger
$to = $_POST['to'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$headers = "From: noreply@seudominio.com.br\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

mail($to, $subject, $message, $headers);
?>
```

3. No JavaScript, chame:
```javascript
fetch('/send-email.php', {
    method: 'POST',
    body: JSON.stringify({
        to: 'cliente@email.com',
        subject: 'Novo Lance Recebido',
        message: 'Você recebeu um novo lance...'
    })
});
```

### Backup Automático

Configure backup automático das planilhas Google Sheets:

1. No Google Sheets, vá em **Arquivo** → **Fazer download** → **Microsoft Excel**
2. Salve uma cópia semanalmente
3. Ou use **Google Takeout** para backup completo

---

## 🎉 Checklist Final

Antes de lançar oficialmente:

- [ ] Todas as 7 planilhas criadas e configuradas no Sheet.best
- [ ] URLs do Sheet.best atualizadas em `config.js`
- [ ] Mercado Pago configurado com credenciais corretas
- [ ] SSL/HTTPS ativo e funcionando
- [ ] Logo personalizado
- [ ] Teste de criação de job funcionando
- [ ] Teste de login de montador funcionando
- [ ] Chat blindado enviando mensagens
- [ ] PWA instalável no celular
- [ ] Geolocalização solicitando permissão
- [ ] Console do navegador sem erros críticos
- [ ] Telefone (19) 99876-0212 atualizado em todos os lugares
- [ ] Email de contato configurado

---

## 📞 Suporte

Se encontrar dificuldades:

1. Verifique o Console do navegador (F12 → Console) para erros
2. Revise este guia passo a passo
3. Entre em contato via WhatsApp: (19) 99876-0212

---

## 🔄 Próximos Passos

Após instalação:

1. **Cadastrar montadores** manualmente ou criar página de cadastro
2. **Testar fluxo completo** com clientes e montadores reais
3. **Trocar credenciais do Mercado Pago** de teste para produção
4. **Configurar Google Analytics** para monitorar acessos
5. **Adicionar pixel do Facebook/Instagram** se for fazer anúncios
6. **Criar backups semanais** das planilhas

---

**Parabéns! Sua plataforma ClickMont Pro está no ar! 🚀**
